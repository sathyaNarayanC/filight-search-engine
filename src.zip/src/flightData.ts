export interface IData{
    flight_name:String,
    origin_city: String,
    destination_city:String,
    price: String,
    depart_time: String,
    Arrive_time: String
}